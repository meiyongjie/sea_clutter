import torch
import os


class Configs:
    def __init__(self):
        # --- 1. 数据配置 ---
        self.file_path = '20210106155330_01_staring.mat'
        self.pulse_start = 0
        self.pulse_end = 1000
        self.range_cell_limit = 2000

        # 根据文献相空间重构理论确定的最优输入长度
        self.seq_len = 64
        self.pred_len = 8
        self.train_ratio = 0.8

        # --- 3. SCPNet 模型配置 ---
        self.enc_in = 1  # 输入通道数(幅度序列为1)
        self.d_model = 32  # GRU 的隐藏层维度 (Hidden Size)
        self.e_layers = 2  # GRU 的层数 (论文中 Encoder 和 Decoder 均为2层)
        self.n_heads = 4  # Attention 的多头注意力头数

        # --- 4. 训练配置 ---
        self.do_train = False
        self.save_dir = './checkpoints'
        self.model_name = 'SCPNet_model_2.pth'  # 修改模型保存名字区分 PatchTST
        self.model_path = os.path.join(self.save_dir, self.model_name)

        self.batch_size = 128
        self.learning_rate = 0.001
        self.epochs = 50
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


args = Configs()