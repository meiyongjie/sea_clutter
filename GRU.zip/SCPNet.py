import torch
import torch.nn as nn


class SCPNet(nn.Module):
    """
    Sea Clutter Prediction Network (SCPNet)
    基于注意力增强 Seq2Seq 的海杂波预测网络
    """

    def __init__(self, configs):
        super(SCPNet, self).__init__()
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.hidden_size = configs.d_model
        self.num_layers = configs.e_layers
        self.n_heads = configs.n_heads

        # 1. Encoder (编码器): 2层 GRU
        # 用于提取历史序列(seq_len)的混沌动力学特征
        self.encoder = nn.GRU(input_size=configs.enc_in,
                              hidden_size=self.hidden_size,
                              num_layers=self.num_layers,
                              batch_first=True)

        # 2. Decoder (解码器): 2层 GRU
        # 用于生成未来序列(pred_len)的基础隐藏特征
        self.decoder = nn.GRU(input_size=configs.enc_in,
                              hidden_size=self.hidden_size,
                              num_layers=self.num_layers,
                              batch_first=True)

        # 3. Self-Attention (自注意力机制)
        # 对解码器的特征进行打分、筛选和聚焦
        self.attention = nn.MultiheadAttention(embed_dim=self.hidden_size,
                                               num_heads=self.n_heads,
                                               batch_first=True)

        # 4. Dense / Linear Layer (全连接输出层)
        # 接收【解码器原始特征】与【Attention增强特征】的拼接，映射到最终输出
        # 因为是拼接，所以输入维度是 hidden_size * 2
        self.linear = nn.Linear(self.hidden_size * 2, configs.enc_in)

    def forward(self, x):
        # x shape: [Batch, seq_len, 1]
        batch_size = x.size(0)

        # --- 1. Encoder 阶段 ---
        # enc_hidden 包含了整个输入序列的浓缩状态信息
        # shape:[num_layers, Batch, hidden_size]
        _, enc_hidden = self.encoder(x)

        # --- 2. Decoder 阶段 ---
        # 为了实现 MIMO (多输入多输出) 一次性预测 k 步，我们向解码器输入全 0 的占位符矩阵
        # 迫使解码器完全依赖编码器传来的 enc_hidden 进行推演，从而切断单步自回归带来的误差累积
        dec_input = torch.zeros(batch_size, self.pred_len, x.size(-1)).to(x.device)

        # 将 Encoder 的最后状态作为 Decoder 的初始状态
        dec_out, _ = self.decoder(dec_input, enc_hidden)
        # dec_out shape:[Batch, pred_len, hidden_size]

        # --- 3. Self-Attention 阶段 ---
        # Q, K, V 均来源于解码器输出，进行自我特征相关性计算
        attn_out, _ = self.attention(dec_out, dec_out, dec_out)
        # attn_out shape:[Batch, pred_len, hidden_size]

        # --- 4. 融合与输出阶段 ---
        # 将原始解码特征与注意力特征在特征维度（最后一个维度）进行拼接 (Concatenation)
        fused_features = torch.cat((dec_out, attn_out), dim=-1)
        # fused_features shape:[Batch, pred_len, hidden_size * 2]

        # 通过线性层直接输出 k 个预测点
        outputs = self.linear(fused_features)
        # outputs shape: [Batch, pred_len, 1]

        return outputs