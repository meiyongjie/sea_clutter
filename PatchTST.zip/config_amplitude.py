import torch
import os


class Configs:
    def __init__(self):
        # --- 1. 数据配置 ---
        self.file_path = '20210106155330_01_staring.mat'
        self.pulse_start = 0
        self.pulse_end = 1000

        self.range_cell_limit = 2000


        self.seq_len = 64
        # 【修改】每次只输出预测未来 8 个单元
        self.pred_len = 8

        self.train_ratio = 0.8

        # --- 3. PatchTST 模型配置 ---
        self.enc_in = 1
        self.d_model = 64
        self.n_heads = 4
        self.e_layers = 2
        self.d_ff = 256
        self.dropout = 0.1
        self.fc_dropout = 0.1
        self.head_dropout = 0.0

        self.patch_len = 8
        self.stride = 4
        self.padding_patch = 'end'
        self.revin = 1
        self.affine = 0
        self.subtract_last = 0
        self.decomposition = 0
        self.kernel_size = 25
        self.individual = 0

        # --- 4. 训练配置 ---
        self.do_train = False
        self.save_dir = './checkpoints'
        self.model_name = 'patchtst_amplitude.pth'
        self.model_path = os.path.join(self.save_dir, self.model_name)

        self.batch_size = 128
        self.learning_rate = 0.001
        self.epochs = 50
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


args = Configs()