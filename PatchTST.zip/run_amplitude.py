import os
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from dataset_amplitude import get_data
from config_amplitude import args
# from config_SCPNet import args
# from config_lstm import args
from PatchTST import Model as PatchTSTModel
# from SCPNet import SCPNet
# from lstm import SeaClutterLSTM


def train(args, train_loader):
    model = PatchTSTModel(args).to(args.device)
    # model = SCPNet(args).to(args.device)
    # model = SeaClutterLSTM(args).to(args.device)
    criterion = nn.SmoothL1Loss()
    optimizer = optim.AdamW(model.parameters(), lr=args.learning_rate)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)

    print(f"开始训练 PatchTST (Device: {args.device})...")
    # print(f"开始训练 SCPNet (Device: {args.device})...")
    # print(f"开始训练 LSTM (Device: {args.device})...")
    for epoch in range(args.epochs):
        model.train()
        train_loss = 0
        for batch_x, batch_y in train_loader:
            batch_x = batch_x.to(args.device)
            batch_y = batch_y.to(args.device)
            optimizer.zero_grad()
            outputs = model(batch_x)
            outputs = outputs[:, -args.pred_len:, :]
            batch_y = batch_y[:, -args.pred_len:, :]
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        scheduler.step()
        if (epoch + 1) % 5 == 0:
            print(f"Epoch {epoch + 1}/{args.epochs} | Loss: {train_loss / len(train_loader):.6f}")

    # 【新增】训练结束后保存模型权重
    print(f"训练完成，正在保存模型到: {args.model_path}")
    if not os.path.exists(args.save_dir): os.makedirs(args.save_dir)
    torch.save(model.state_dict(), args.model_path)

    return model


# ================= 核心：带定量分析的递归预测 =================
# error_threshold_db: 允许的最大误差dB，超过此值认为预测失效
def recursive_range(args, model, scaler, target_pulse_rel_idx=0, max_steps=500, error_threshold_db=5.0):
    # 这里的 target_pulse_rel_idx 是相对于测试集(后200个脉冲)的索引
    # 比如设为 0，就是测试第 800 号脉冲 (因为总共1000个，前800训练，后200测试)
    # 我们需要计算在原始数据中的绝对索引
    total_pulses = args.pulse_end - args.pulse_start
    train_pulses = int(total_pulses * args.train_ratio)
    real_pulse_idx = args.pulse_start + train_pulses + target_pulse_rel_idx

    print(f"\n=== [极限测试] 对 Pulse #{real_pulse_idx} 进行距离维推演 ===")

    # 1. 读取单脉冲数据
    try:
        mat = scipy.io.loadmat(args.file_path)
        keys = [k for k in mat.keys() if 'complex' in k]
        raw_data = mat[keys[0]]
        profile_data = raw_data[real_pulse_idx, :args.range_cell_limit]
    except Exception as e:
        print(f"读取失败: {e}");
        return

    # 2. 预处理
    profile_db = 20 * np.log10(np.abs(profile_data) + 1e-5).reshape(-1, 1)
    profile_scaled = scaler.transform(profile_db)

    # 3. 准备数据片段
    # Context: 前 64 个点 (近处)
    context_data = profile_scaled[:args.seq_len]
    # Ground Truth: 从 64 开始到 max_steps
    end_idx = min(len(profile_scaled), args.seq_len + max_steps)
    true_future = profile_scaled[args.seq_len: end_idx]

    current_seq = torch.FloatTensor(context_data).unsqueeze(0).to(args.device)

    # 4. 递归推演 Loop
    model.eval()
    recursive_preds = []

    steps_needed = int(np.ceil((end_idx - args.seq_len) / args.pred_len))

    print(f"推演目标: +{len(true_future)} 距离单元...")
    with torch.no_grad():
        for i in range(steps_needed):
            output = model(current_seq)
            output = output[:, -args.pred_len:, :]
            pred_block = output.cpu().numpy().reshape(-1, 1)
            recursive_preds.append(pred_block)
            current_seq = torch.cat([current_seq[:, args.pred_len:, :], output], dim=1)

    # 5. 结果处理
    pred_array = np.concatenate(recursive_preds, axis=0)
    pred_array = pred_array[:len(true_future)]

    # 6. 还原 dB
    context_db = scaler.inverse_transform(context_data)
    true_future_db = scaler.inverse_transform(true_future)
    pred_future_db = scaler.inverse_transform(pred_array)

    # ================= 7. 定量失效分析 =================
    # 计算逐点绝对误差 (dB)
    abs_error = np.abs(true_future_db - pred_future_db)

    failure_idx = -1
    # 判定逻辑：如果连续 5 个距离单元的误差都 > 阈值，则认为在第 1 个超标点处失效
    window = 5
    for i in range(len(abs_error) - window):
        if np.all(abs_error[i: i + window] > error_threshold_db):
            failure_idx = i
            break

    print("\n" + "=" * 40)
    if failure_idx != -1:
        # 失效点是相对于 Prediction Start (即第64个点) 的偏移
        abs_failure_idx = args.seq_len + failure_idx
        print(f"🔴 预测失效点: 第 {abs_failure_idx} 个距离单元")
        print(f"   (误差连续 {window} 次超过 {error_threshold_db} dB)")
        print(f"   有效预测范围: 距离单元 {args.seq_len} -> {abs_failure_idx}")
        valid_errors_db = abs_error[:abs_failure_idx]
        mae_db = np.mean(valid_errors_db)
        print("-"*40)
        print(f"MAE: {mae_db:.4f}")
    else:
        print(f"🟢 全程预测稳定 (误差未持续超过 {error_threshold_db} dB)")
    print("=" * 40)

    # ================= 8. 绘图 =================
    plt.figure(figsize=(14, 8))

    # 子图 1: 波形对比
    plt.subplot(2, 1, 1)
    x_context = np.arange(0, args.seq_len)
    x_future = np.arange(args.seq_len, args.seq_len + len(true_future_db))

    plt.plot(x_context, context_db, color='black', label='Context')
    plt.plot(x_future, true_future_db, color='green', alpha=0.6, label='Ground Truth')
    plt.plot(x_future, pred_future_db, color='red', linestyle='--', label='LSTM')

    if failure_idx != -1:
        plt.axvline(x=args.seq_len + failure_idx, color='blue', linestyle='-.', label='Failure Point')
        # 用阴影标出失效区域
        plt.axvspan(args.seq_len + failure_idx, x_future[-1], color='red', alpha=0.1)

    plt.ylabel('Amplitude (dB)')
    plt.legend(loc='upper right')
    plt.title(f'Recursive Forecast (Pulse #{real_pulse_idx})')
    plt.grid(True, alpha=0.3)

    # 子图 2: 误差曲线
    plt.subplot(2, 1, 2)
    plt.plot(x_future, abs_error, color='purple', label='Absolute Error (dB)')
    plt.axhline(y=error_threshold_db, color='orange', linestyle='--', label=f'Threshold ({error_threshold_db}dB)')
    plt.ylabel('Error (dB)')
    plt.xlabel('Range Bin Index')
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()


if __name__ == '__main__':
    train_loader, test_loader, scaler = get_data(args)
    if train_loader is not None:
        if args.do_train:
            model = train(args, train_loader)
        else:
            model = PatchTSTModel(args).to(args.device)
            # model = SCPNet(args).to(args.device)
            # model = SeaClutterLSTM(args).to(args.device)
            model.load_state_dict(torch.load(args.model_path))
            print("模型加载成功！")
        # 测试第 0 号测试脉冲 (即总索引 800)
        # 推演未来 500 个距离单元
        # 误差阈值设为 5dB (视海杂波动态范围而定，3~5dB是常见标准)
        recursive_range(args, model, scaler,
                             target_pulse_rel_idx=0,
                             max_steps=100,
                             error_threshold_db=5.0)