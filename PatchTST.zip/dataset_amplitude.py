import torch
from torch.utils.data import DataLoader, Dataset
import numpy as np
import scipy.io
from sklearn.preprocessing import MinMaxScaler


class RangeClutterDataset(Dataset):
    def __init__(self, data_2d, seq_len, pred_len):
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.data = data_2d

        # data_2d shape: [Range, Pulses]
        self.n_range, self.n_pulses = self.data.shape

        # 计算单个脉冲能切出多少个样本 (沿着距离方向切)
        self.samples_per_pulse = self.n_range - seq_len - pred_len + 1

        if self.samples_per_pulse <= 0:
            raise ValueError(f"距离单元长度({self.n_range})不足以构建序列({seq_len}+{pred_len})")

        self.total_samples = self.samples_per_pulse * self.n_pulses

    def __len__(self):
        return self.total_samples

    def __getitem__(self, index):
        # 2D 索引映射
        pulse_idx = index // self.samples_per_pulse  # 第几条脉冲
        range_start = index % self.samples_per_pulse  # 距离起始点

        s_end = range_start + self.seq_len
        r_end = s_end + self.pred_len

        # 沿着行(距离)切片，列(脉冲)固定
        seq_x = self.data[range_start:s_end, pulse_idx]
        seq_y = self.data[s_end:r_end, pulse_idx]

        return torch.FloatTensor(seq_x).unsqueeze(-1), torch.FloatTensor(seq_y).unsqueeze(-1)


def get_data(args):
    print(f"读取数据: {args.file_path}")
    try:
        mat = scipy.io.loadmat(args.file_path)
        target_key = 'amplitude_complex_T1'
        if target_key in mat:
            raw_data = mat[target_key]
            print(f"✅ 成功提取 T1 模式数据: {raw_data.shape}")
        else:
            raise KeyError(f"在文件中未找到 '{target_key}' 变量！请检查 MAT 文件。")
    except Exception as e:
        print(f"数据提取错误: {e}")
        return None, None, None, None, None

    # 1. 截取有效区域
    # 选取所有脉冲，前 1280 个距离单元
    # data_region = raw_data[:, :args.range_cell_limit]
    data_region = raw_data[args.pulse_start:args.pulse_end, :args.range_cell_limit]

    # 2. 【核心】转置：[Time, Range] -> [Range, Time]
    # 这样 Dataset 就会沿着“距离”方向构建序列
    data_transposed = data_region.T
    print(f"转置后用于训练的维度 (Range x Time): {data_transposed.shape}")

    # 3. 预处理 (Abs -> dB)
    amplitude = np.abs(data_transposed)
    data_db = 20 * np.log10(amplitude + 1e-5)

    # 4. 全局归一化
    scaler = MinMaxScaler(feature_range=(0, 1))
    N, C = data_db.shape
    data_flat = data_db.flatten().reshape(-1, 1)
    scaler.fit(data_flat)
    data_scaled = scaler.transform(data_flat).reshape(N, C)

    # 5. 划分训练/测试 (按脉冲划分)
    # 前 80% 的脉冲用于训练，后 20% 的脉冲用于测试
    split_idx = int(C * args.train_ratio)
    train_data = data_scaled[:, :split_idx]
    test_data = data_scaled[:, split_idx:]

    print(f"训练集包含脉冲数: {train_data.shape[1]}")
    print(f"测试集包含脉冲数: {test_data.shape[1]}")

    train_loader = DataLoader(RangeClutterDataset(train_data, args.seq_len, args.pred_len),
                              batch_size=args.batch_size, shuffle=True, drop_last=True)

    # 测试集 loader 仅用于计算 Loss，不用做递归测试
    test_loader = DataLoader(RangeClutterDataset(test_data, args.seq_len, args.pred_len),
                             batch_size=args.batch_size, shuffle=False)

    return train_loader, test_loader, scaler