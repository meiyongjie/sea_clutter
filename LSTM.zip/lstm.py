import torch
import torch.nn as nn

class SeaClutterLSTM(nn.Module):
    def __init__(self, config):
        super(SeaClutterLSTM,self).__init__()

        self.hidden_size = config.hidden_size
        self.num_layers = config.num_layers

        self.lstm = nn.LSTM(
            input_size=config.input_size,
            hidden_size=config.hidden_size,
            num_layers=config.num_layers,
            batch_first=True,
            dropout=config.dropout,
        )

        self.fc = nn.Linear(config.hidden_size, config.pred_len)

    def forward(self, x):
        out,_ = self.lstm(x)
        last_step_out = out[:,-1,:]
        prediction = self.fc(last_step_out)
        return prediction.unsqueeze(-1)