import torch
import os


class Configs:
    def __init__(self):
        # --- 1. 数据配置 ---
        self.file_path = '20210106155330_01_staring.mat'
        self.pulse_start = 0
        self.pulse_end = 1000

        self.range_cell_limit = 2000


        self.seq_len = 64
        # 【修改】每次只输出预测未来 8 个单元
        self.pred_len = 1
        self.train_ratio = 0.8

        # --- 3. LSTM 模型配置 ---
        self.input_size = 1
        self.hidden_size = 64
        self.num_layers = 2
        self.dropout = 0.1


        # --- 4. 训练配置 ---
        self.do_train = True
        self.save_dir = './checkpoints'
        self.model_name = 'lstm_amplitude.pth'
        self.model_path = os.path.join(self.save_dir, self.model_name)

        self.batch_size = 128
        self.learning_rate = 0.001
        self.epochs = 30
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


args = Configs()