import os

import torch


class Configs:
    def __init__(self):
        # --- 1. 数据配置 ---
        self.file_path = '20210106155330_01_staring.mat'

        # 选取前 100 个脉冲用于学习距离特性
        self.pulse_start = 0
        self.pulse_end = 100

        # 距离单元限制
        self.range_cell_limit = 1280

        self.train_ratio = 0.8

        # --- 2. 序列配置 ---
        self.seq_len = 64  # 看前 64 个距离门
        self.pred_len = 8  # 预测后 8 个距离门

        # --- 3. PatchTST 模型配置 ---
        self.enc_in = 2  # 【修改】输入通道改为 2 (Real, Imag)
        self.d_model = 64
        self.n_heads = 4
        self.e_layers = 2
        self.d_ff = 256
        self.dropout = 0.1
        self.fc_dropout = 0.1
        self.head_dropout = 0.0

        self.patch_len = 8
        self.stride = 4
        self.padding_patch = 'end'
        self.revin = 1  # RevIN 会分别对 I 和 Q 进行归一化，非常适合
        self.affine = 0
        self.subtract_last = 0
        self.decomposition = 0
        self.kernel_size = 25
        self.individual = 0

        # --- 4. 训练配置 ---
        self.do_train = True
        self.save_dir = './checkpoints'
        self.model_name = 'patchtst_complex.pth'
        self.model_path = os.path.join(self.save_dir, self.model_name)

        self.batch_size = 64
        self.learning_rate = 0.0005
        self.epochs = 30
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


args = Configs()