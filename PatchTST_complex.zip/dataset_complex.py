import torch
from torch.utils.data import DataLoader, Dataset
import numpy as np
import scipy.io
from sklearn.preprocessing import StandardScaler


class ComplexRangeDataset(Dataset):
    def __init__(self, data_3d, seq_len, pred_len):
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.data = data_3d  # [Range, Pulses, 2]

        # data_3d shape: [Range, Pulses, Channels=2]
        self.n_range, self.n_pulses, self.n_channels = self.data.shape

        self.samples_per_pulse = self.n_range - seq_len - pred_len + 1

        if self.samples_per_pulse <= 0:
            raise ValueError(f"距离单元不足")

        self.total_samples = self.samples_per_pulse * self.n_pulses

    def __len__(self):
        return self.total_samples

    def __getitem__(self, index):
        # 2D 索引映射
        pulse_idx = index // self.samples_per_pulse
        range_start = index % self.samples_per_pulse

        s_end = range_start + self.seq_len
        r_end = s_end + self.pred_len

        # 切片: [seq_len, 2]
        # data[距离索引, 脉冲索引, 通道索引]
        seq_x = self.data[range_start:s_end, pulse_idx, :]
        seq_y = self.data[s_end:r_end, pulse_idx, :]

        # PatchTST 输入要求 [Seq, Channel]
        return torch.FloatTensor(seq_x), torch.FloatTensor(seq_y)


def get_data(args):
    print(f"读取数据: {args.file_path}")
    try:
        mat = scipy.io.loadmat(args.file_path)
        keys = [k for k in mat.keys() if 'complex' in k]
        raw_data = mat[keys[0]]
    except Exception as e:
        print(f"错误: {e}");
        return None, None, None

    # 1. 截取 [Time, Range] -> [100, 1280]
    data_region = raw_data[args.pulse_start: args.pulse_end, :args.range_cell_limit]

    # 2. 转置 -> [Range, Time] (预测距离维)
    data_transposed = data_region.T

    # 3. 分离实部和虚部
    real_part = np.real(data_transposed)
    imag_part = np.imag(data_transposed)

    # 堆叠成 [Range, Time, 2]
    # axis=2 表示在最后增加一个通道维度
    data_complex = np.stack([real_part, imag_part], axis=2)
    print(f"复数数据维度 (Range x Time x 2): {data_complex.shape}")

    # 4. 归一化 (使用 StandardScaler 对 I/Q 分别归一化)
    # 需要先 reshape 成 [N, 2] 才能 fit
    N_range, N_time, N_ch = data_complex.shape
    data_flat = data_complex.reshape(-1, N_ch)  # [N_total, 2]

    scaler = StandardScaler()
    scaler.fit(data_flat)
    data_scaled_flat = scaler.transform(data_flat)

    # 恢复形状
    data_scaled = data_scaled_flat.reshape(N_range, N_time, N_ch)

    # 5. 划分训练/测试 (按脉冲划分)
    split_idx = int(N_time * args.train_ratio)
    train_data = data_scaled[:, :split_idx, :]
    test_data = data_scaled[:, split_idx:, :]

    print(f"训练集脉冲: {train_data.shape[1]}, 测试集脉冲: {test_data.shape[1]}")

    # 6. Loader
    train_loader = DataLoader(
        ComplexRangeDataset(train_data, args.seq_len, args.pred_len),
        batch_size=args.batch_size, shuffle=True, drop_last=True
    )

    return train_loader, scaler, data_scaled