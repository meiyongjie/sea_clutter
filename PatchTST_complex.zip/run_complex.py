import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
import scipy.io
from dataset_complex import get_data
from config_complex import args
from PatchTST import Model as PatchTSTModel


def train(args, train_loader):
    model = PatchTSTModel(args).to(args.device)
    criterion = nn.MSELoss()  # I/Q 预测通常用 MSE
    optimizer = optim.AdamW(model.parameters(), lr=args.learning_rate)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)

    print(f"开始训练 PatchTST (Complex I/Q Prediction)...")
    for epoch in range(args.epochs):
        model.train()
        train_loss = 0
        for batch_x, batch_y in train_loader:
            batch_x = batch_x.to(args.device)
            batch_y = batch_y.to(args.device)

            optimizer.zero_grad()
            outputs = model(batch_x)

            # 截取输出
            outputs = outputs[:, -args.pred_len:, :]
            batch_y = batch_y[:, -args.pred_len:, :]

            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        scheduler.step()
        if (epoch + 1) % 5 == 0:
            print(f"Epoch {epoch + 1}/{args.epochs} | Loss: {train_loss / len(train_loader):.6f}")
    print(f"训练完成，正在保存模型到: {args.save_path}")
    torch.save(model.state_dict(), args.save_path)

    return model


# ================= 复数递归预测 =================
def recursive_complex(args, model, scaler, full_data, target_pulse_rel_idx=0, max_steps=500):
    # 找到对应的脉冲列
    # full_data: [Range, Time, 2]
    total_pulses = full_data.shape[1]
    split_idx = int(total_pulses * args.train_ratio)
    target_pulse_idx = split_idx + target_pulse_rel_idx

    print(f"\n=== [I/Q 距离维推演] Pulse #{target_pulse_idx} ===")

    # 1. 取出该脉冲的完整 I/Q 序列 [Range, 2]
    pulse_data = full_data[:, target_pulse_idx, :]

    # 2. 准备 Context (前64个距离单元)
    # 我们从近海 (Index 0) 开始
    start_idx = 0
    context_data = pulse_data[start_idx: start_idx + args.seq_len]

    # 3. 准备 Ground Truth (后续距离单元)
    end_idx = min(len(pulse_data), start_idx + args.seq_len + max_steps)
    true_future_scaled = pulse_data[start_idx + args.seq_len: end_idx]
    test_len = len(true_future_scaled)

    print(f"推演距离范围: {args.seq_len} -> {args.seq_len + test_len} 距离门")

    # 初始输入 [1, 64, 2]
    current_seq = torch.FloatTensor(context_data).unsqueeze(0).to(args.device)

    # 4. 递归推演 (Block Recursive)
    model.eval()
    recursive_preds = []
    blocks_needed = int(np.ceil(test_len / args.pred_len))

    with torch.no_grad():
        for i in range(blocks_needed):
            # A. 预测 [1, 8, 2]
            output = model(current_seq)
            output = output[:, -args.pred_len:, :]

            # B. 全部采纳
            pred_block = output.cpu().numpy().reshape(-1, 2)  # [8, 2]
            recursive_preds.append(pred_block)

            # C. 更新输入
            current_seq = torch.cat([current_seq[:, args.pred_len:, :], output], dim=1)

    # 5. 拼接结果
    pred_array = np.concatenate(recursive_preds, axis=0)
    pred_array = pred_array[:test_len]

    # 6. 反归一化 (还原为真实 I/Q)
    # Context
    context_real = scaler.inverse_transform(context_data)
    # Truth
    true_future_real = scaler.inverse_transform(true_future_scaled)
    # Pred
    pred_future_real = scaler.inverse_transform(pred_array)

    # 7. 合成幅度 (Amplitude = sqrt(I^2 + Q^2))
    # 我们画图时通常看幅度，或者 dB
    def to_amp_db(iq_data):
        amp = np.sqrt(iq_data[:, 0] ** 2 + iq_data[:, 1] ** 2)
        return 20 * np.log10(amp + 1e-5)

    context_amp = to_amp_db(context_real)
    true_amp = to_amp_db(true_future_real)
    pred_amp = to_amp_db(pred_future_real)

    # 8. 绘图
    plt.figure(figsize=(14, 8))

    plt.subplot(2, 1, 1)
    x_context = np.arange(0, args.seq_len)
    x_future = np.arange(args.seq_len, args.seq_len + test_len)

    plt.plot(x_context, context_amp, color='black', label='Context (I/Q Input)')
    plt.plot(x_future, true_amp, color='green', alpha=0.6, label='Ground Truth (Amp)')
    plt.plot(x_future, pred_amp, color='red', linestyle='--', label='PatchTST I/Q Pred')

    plt.axvline(x=args.seq_len, color='blue', linestyle=':', label='Start')

    plt.ylabel('Amplitude (dB)')
    plt.title(f'Complex-Valued Range Prediction (Pulse #{target_pulse_idx})')
    plt.legend()
    plt.grid(True, alpha=0.3)

    # 子图2：看一看 I 路和 Q 路的细节
    plt.subplot(2, 1, 2)
    # 只画未来部分的 I 路对比
    plt.plot(x_future, true_future_real[:, 0], color='green', alpha=0.5, label='True I-Channel')
    plt.plot(x_future, pred_future_real[:, 0], color='red', linestyle='--', alpha=0.8, label='Pred I-Channel')
    plt.ylabel('Voltage (I-Channel)')
    plt.xlabel('Range Bin Index')
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()


if __name__ == '__main__':
    train_loader, scaler, full_data = get_data(args)
    if train_loader is not None:
        if args.do_train:
            model = train(args, train_loader)
        else:
            model = PatchTSTModel(args).to(args.device)
            model.load_state_dict(torch.load(args.model_path))
            print("模型加载成功！")
        # 测试第 0 个测试脉冲
        recursive_complex(args, model, scaler, full_data,
                               target_pulse_rel_idx=0,
                               max_steps=500)